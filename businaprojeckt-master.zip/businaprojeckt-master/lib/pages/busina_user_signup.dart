import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';

class SignupPage extends StatefulWidget {
  @override
  _SignupPageState createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final db = Firestore.instance;
  String _email, _password, _confirmpass, _name, _contact;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Register"),
        backgroundColor: Colors.greenAccent,
        elevation: 0.0,
        iconTheme: new IconThemeData(
          color: Colors.white,
        ),
      ),
      body: Container(
        alignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            stops: [0.1,0.5,0.7,0.9],
            colors: [
              Colors.amber[600],
              Colors.amber[900],
              Colors.amber[900],
              Colors.amber[900],
            ]
          ),
        ),
      )
    );
  }

  void signUp() async {
    final formState = _formKey.currentState;
    if (formState.validate()) {
      formState.save();
      if (_password == _confirmpass) {
        try {
          final FirebaseAuth _auth = FirebaseAuth.instance;
          final FirebaseUser user = (await _auth.createUserWithEmailAndPassword(
            email: _email,
            password: _password,
          )) .user;
          user.sendEmailVerification();

          UserUpdateInfo info = new UserUpdateInfo();
          info.displayName = _name;
          user.updateProfile(info);

          db.collection('users_db').document().setData({
            'name': _name,
            'uid': user.uid,
            'email': _email,
            'isEmailVerified': user.isEmailVerified,
            'photoUrl': user.photoUrl,
            'contact': _contact,
          });

          Navigator.of(context).pop();
        } catch (error) {
          print(error.code);
          if (error.code == 'ERROR_WEAK_PASSWORD') {
            toastShow('Password too weak', Colors.orange);
          } else if (error.code == 'ERROR_INVALID_EMAIL') {
            toastShow('Invalid email', Colors.orange);
          } else if (error.code == 'ERROR_EMAIL_ALREADY_IN_USE') {
            toastShow('Email already in use', Colors.orange);
          }
        }
      } else {
        toastShow('Password does not match', Colors.red);
      }
    }
  }

  void toastShow(txt, colr) {
    Fluttertoast.showToast(
        msg: txt,
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIos: 1,
        backgroundColor: colr,
        textColor: Colors.white,
        fontSize: 14.0);
  }
}
